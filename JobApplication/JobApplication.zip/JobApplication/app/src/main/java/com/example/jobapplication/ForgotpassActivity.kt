package com.example.jobapplication

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth


class ForgotpassActivity : AppCompatActivity() {

    private var mAuth: FirebaseAuth? = null
    lateinit var btncnt:Button
    lateinit var edtespmail:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgotpass)



        mAuth = FirebaseAuth.getInstance()
        btncnt=findViewById(R.id.btncnt)
        edtespmail=findViewById(R.id.edtespmail)

        initView()
    }

    private fun initView() {

        btncnt.setOnClickListener (object : View.OnClickListener {
            override fun onClick(v: View?) {
                val email: String = edtespmail.getText().toString().trim()
                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(
                        application,
                        "Enter your registered email id",
                        Toast.LENGTH_SHORT
                    ).show()
                    return
                }

                mAuth?.sendPasswordResetEmail(email)
                    ?.addOnCompleteListener(OnCompleteListener<Void?> { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(
                                this@ForgotpassActivity,
                                "We have sent you instructions to reset your password!",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@ForgotpassActivity,
                                "Failed to send reset email!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    })
            }
        })
        }
    }
