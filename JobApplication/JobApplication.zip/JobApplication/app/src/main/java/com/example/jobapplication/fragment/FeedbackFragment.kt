package com.example.jobapplication.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.jobapplication.AddFeedback
import com.example.jobapplication.R
import com.google.firebase.database.FirebaseDatabase


class FeedbackFragment : Fragment() {

    lateinit var btnsubmit:Button
    lateinit var edtemailf:EditText
    lateinit var edtnamef:EditText
    lateinit var edtmsg:EditText

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_feedback, container, false)

        btnsubmit=view.findViewById(R.id.btnsubmit)
        edtemailf=view.findViewById(R.id.edtemailf)
        edtnamef=view.findViewById(R.id.edtnamef)
        edtmsg=view.findViewById(R.id.edtmsg)

        initView(view)
        return view

    }

    private fun initView(view: View?) {
        btnsubmit.setOnClickListener {



            val ref= FirebaseDatabase.getInstance().getReference("Feedback")
            val userid = ref.push().key
            val user = AddFeedback(name = edtnamef.text.toString(),email = edtemailf.text.toString(),message = edtmsg.text.toString() )
            ref.child(userid!!).setValue(user).addOnCompleteListener {

                Toast.makeText( activity, "Sent Successfully", Toast.LENGTH_SHORT).show()

                    edtemailf.text.clear()
                    edtnamef.text.clear()
                    edtmsg.text.clear()
            }




        }
    }
    }


