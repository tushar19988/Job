package com.example.jobapplication

class AddData(val  email: String, val mobilenumber: String, val password: String, val confirmpassword: String)