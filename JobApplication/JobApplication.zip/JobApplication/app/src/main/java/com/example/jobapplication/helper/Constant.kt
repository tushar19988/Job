package com.example.androidtraining.helper

const val IS_LOGIN="is_login"




