package com.example.jobapplication

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.example.androidtraining.helper.IS_LOGIN
import com.example.jobapplication.authentication.SigninActivity
import com.example.jobapplication.fragment.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.example.androidtraining.helper.PreferenceHelper.get



class NavigationActivity : BaseActivity(), NavigationView.OnNavigationItemSelectedListener {

    lateinit var  drawerLayout:DrawerLayout
    private var mAuth: FirebaseAuth? = null
    lateinit var toolbar: Toolbar


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation)





        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)


        drawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val nav_view: BottomNavigationView = findViewById(R.id.navb_view)


        val toggle =
            ActionBarDrawerToggle(this, drawerLayout,toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        toolbar.setNavigationIcon(R.drawable.navone);
        drawerLayout.addDrawerListener(toggle)



        navView.setNavigationItemSelectedListener(this)
        nav_view.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)

        val fragment= HomeFragment()
        replaceFragment(fragment)



    }



    override fun onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.framLayout,fragment).commit()

    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.nav_home ->{
                val fragment= HomeFragment()
                toolbar.setTitle("Gujarat")
                replaceFragment(fragment)

            }
            R.id.nav_results ->{
                val fragment= ResultsFragment()
                toolbar.setTitle("Sarkari results")
                replaceFragment(fragment)

            }
            R.id.nav_employee ->{
                val fragment= EmployeeFragment()
                toolbar.setTitle("Employment news")
                replaceFragment(fragment)

            }
            R.id.nav_feedback ->{
                val fragment= FeedbackFragment()
                toolbar.setTitle("Feedback")
                replaceFragment(fragment)

            }
            R.id.nav_aboutus ->{
                val fragment= AboutusFragment()
                toolbar.setTitle("About us")
                replaceFragment(fragment)

            }
            R.id.nav_logout->{


                val builder: android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(this)

                builder.setTitle("Confirm")
                builder.setMessage("Are you sure?")

                builder.setPositiveButton(
                    "YES",
                    DialogInterface.OnClickListener { dialog, which ->

                        if (prif[IS_LOGIN]!!){
                            mAuth?.signOut()
                            finish()
                            val intent = Intent(this@NavigationActivity, SigninActivity::class.java)
                            startActivity(intent)
                            dialog.dismiss()
                        }else{
                            Toast.makeText(this, "You are not logged in,Want to Login?? ", Toast.LENGTH_SHORT).show()
                        }



                    })

                builder.setNegativeButton(
                    "NO",

                    DialogInterface.OnClickListener { dialog, which -> // Do nothing
                        dialog.dismiss()
                    })

                val alert: android.app.AlertDialog? = builder.create()
                alert?.show()








            }

        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener {item ->
        when(item.itemId){
            R.id.navb_guj ->{
                val fragment=HomeFragment()
                toolbar.setTitle("Gujarat")
                replaceFragment(fragment)
                return@OnNavigationItemSelectedListener true

            }
            R.id.navb_rajsthan->{
                val fragment=RajasthanFragment()
                toolbar.setTitle("Rajasthan")
                replaceFragment(fragment)
                return@OnNavigationItemSelectedListener true

            }
            R.id.navb_mp ->{
                val fragment=MpFragment()
                toolbar.setTitle("MadhyaPradesh")
                replaceFragment(fragment)
                return@OnNavigationItemSelectedListener true

            }
            R.id.navb_maharastra ->{
                val fragment=MaharastraFragment()
                toolbar.setTitle("Maharastra")
                replaceFragment(fragment)
                return@OnNavigationItemSelectedListener true

            }
        }
        false
    }




}