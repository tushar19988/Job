package com.example.jobapplication

class AddFeedback(val name: String, val email: String, val message: String)