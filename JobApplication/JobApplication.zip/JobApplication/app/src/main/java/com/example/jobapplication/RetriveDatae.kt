package com.example.jobapplication

class RetriveDatae ( val url:String?=null,
                     val exam:String?=null,
                     val university:String?=null,
                     val location:String?=null)