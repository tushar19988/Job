package com.example.jobapplication

class RetriveData( val companyname:String?=null,
                   val post:String?=null,
                   val education:String?=null,
                    val location:String?=null,
                    val lastdate:String?=null,
                   val jobdetails:String?=null,
                   val jobsummary:String?=null,
                   val about:String?=null)
