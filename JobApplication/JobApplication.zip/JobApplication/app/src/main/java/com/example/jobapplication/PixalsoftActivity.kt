package com.example.jobapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import com.example.jobapplication.fragment.HomeFragment

class PixalsoftActivity : AppCompatActivity() {

    lateinit var txtcname: TextView
    lateinit var txtpost: TextView
    lateinit var txteducation: TextView
    lateinit var txtlocation: TextView
    lateinit var txtlastdate: TextView
    lateinit var txtdetails: TextView
    lateinit var txtsummary: TextView
    lateinit var txtabout: TextView
    lateinit var btnShare:ImageButton
    lateinit var btnback:ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pixalsoft)

        txtcname=findViewById(R.id.txtcname)
        txtpost=findViewById(R.id.txtpost)
        txteducation=findViewById(R.id.txteducation)
        txtlocation=findViewById(R.id.txtlocation)
        txtlastdate=findViewById(R.id.txtlastdate)
        txtdetails=findViewById(R.id.txtdetail)
        txtsummary=findViewById(R.id.txtsummary)
        txtabout=findViewById(R.id.txtabout)
        btnShare=findViewById(R.id.btnShare)
        btnback=findViewById(R.id.btnback)


        initView()
    }
    private fun initView() {
        txtcname.text = intent.getStringExtra("COMPANY_NAME")
        txtpost.text = intent.getStringExtra("POST")
        txteducation.text = intent.getStringExtra("EDUCATION")
        txtlocation.text = intent.getStringExtra("LOCATION")
        txtlastdate.text = intent.getStringExtra("LASTDATE")
        txtdetails.text = intent.getStringExtra("JOB_DETAILS")
        txtsummary.text = intent.getStringExtra("JOB_SUMMARY")
        txtabout.text = intent.getStringExtra("ABOUT")
        btnShare.setOnClickListener {
            //Get text from TextView and store in variable "s"

            //Intent to share the text
            val shareIntent = Intent()
            shareIntent.action = Intent.ACTION_SEND
            shareIntent.type = "text/plain"
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }

        btnback.setOnClickListener {

            val i = Intent(this@PixalsoftActivity, HomeFragment::class.java)
            startActivity(i)
            finish()

        }
    }
}