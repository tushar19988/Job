package com.example.jobapplication

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class BhuneshwerActivity : AppCompatActivity() {

    lateinit var txtemp: TextView
    lateinit var txtexam: TextView
    lateinit var txtuni: TextView
    lateinit var txtlocation: TextView
    lateinit var btnrview: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bhuneshwer)

        txtemp=findViewById(R.id.txtemp)
        txtexam=findViewById(R.id.txtexam)
        txtuni=findViewById(R.id.txtuni)
        txtlocation=findViewById(R.id.txtlocation)
        btnrview=findViewById(R.id.btnrview)


        initView()

    }
    private fun initView() {

        btnrview.setOnClickListener {
            val uri: Uri =
                Uri.parse("https://aiimsbhubaneswar.nic.in/admin/Document/Notices/Notification%20Result937a72ae-285a-428e-bfb0-4dff082ba859.pdf")

            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }

        txtemp.text=intent.getStringExtra("URL")
        txtexam.text=intent.getStringExtra("EXAM")
        txtuni.text=intent.getStringExtra("UNIVERSITY")
        txtlocation.text=intent.getStringExtra("LOCATION")
    }

}