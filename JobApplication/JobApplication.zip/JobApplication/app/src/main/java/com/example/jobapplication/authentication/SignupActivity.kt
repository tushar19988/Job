package com.example.jobapplication.authentication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.NonNull
import com.example.jobapplication.AddData
import com.example.jobapplication.R
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class SignupActivity : AppCompatActivity() {

    lateinit var txtsignin: TextView
    lateinit var btnsignup: Button
    lateinit var edtemaxilu: EditText
    lateinit var edtmnumber: EditText
    lateinit var edtpassu: EditText
    lateinit var edtconfirmpass: EditText
    private var mAuth: FirebaseAuth? = null
    private val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        mAuth = FirebaseAuth.getInstance()
        txtsignin = findViewById(R.id.txtsignin)
        edtemaxilu = findViewById<EditText>(R.id.edtemailu)
        edtmnumber = findViewById<EditText>(R.id.edtmnumber)
        edtpassu = findViewById<EditText>(R.id.edtpassu)
        edtconfirmpass = findViewById<EditText>(R.id.edtconfirmpass)
        btnsignup = findViewById(R.id.btnsignup)


        intiView()

    }

    private fun intiView() {
        txtsignin.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    SigninActivity::class.java
                )
            )
        }
        btnsignup.setOnClickListener {



            val ref = FirebaseDatabase.getInstance().getReference("user")
            val userid = ref.push().key
            val user = AddData(
                email = edtemaxilu.text.toString(),
                mobilenumber = edtmnumber.text.toString(),
                password = edtpassu.text.toString(),
                confirmpassword = edtconfirmpass.text.toString()
            )
            ref.child(userid!!).setValue(user).addOnCompleteListener {
                Toast.makeText(this@SignupActivity, "Sent Successfully", Toast.LENGTH_SHORT).show()

            }
            if (edtemaxilu.text.toString().trim().isEmpty()){
                edtemaxilu.error="can't blank"
            }else if (!edtemaxilu.text.toString().matches(emailPattern.toRegex())){
                edtemaxilu.error="invalid email pattan"
            }else if (edtpassu.text.toString().trim().isEmpty()) {
                edtpassu.error="Can't blank"
            }else if (edtconfirmpass.text.toString().trim().isEmpty()){
                edtconfirmpass.error="Can't blank"
            }
            else if (edtconfirmpass.text.toString().trim().contentEquals(edtpassu.toString()))
            {
                edtconfirmpass.error="Enter Valid Password"
            }
            else if (edtmnumber.text.toString().trim().length < 6 && edtmnumber.text.toString().trim().length > 12)
            {
                edtmnumber.error = "Enter Correct Password"




            mAuth?.createUserWithEmailAndPassword(
                edtemaxilu.text.toString().trim(),
                edtpassu.text.toString().trim()
            )
                ?.addOnCompleteListener(this, object : OnCompleteListener<AuthResult> {
                    override fun onComplete(@NonNull task: Task<AuthResult>) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("TAG", "createUserWithEmail:success")

                            startActivity(
                                Intent(
                                    this@SignupActivity,
                                    SigninActivity::class.java
                                )
                            )

                        } else {
                            // If sign in fails, display a message to the user.
                            Log.d("TAG", "createUserWithEmail:failure", task.getException())
                            Toast.makeText(
                                this@SignupActivity, "Authentication failed.",
                                Toast.LENGTH_SHORT
                            ).show()

                        }
                        // ...
                    }
                })
        }


    }
    }
    }
