package com.example.jobapplication.authentication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.annotation.NonNull
import com.example.androidtraining.helper.IS_LOGIN
import com.example.androidtraining.helper.PreferenceHelper.set
import com.example.jobapplication.*
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference

class SigninActivity : BaseActivity() {

    lateinit var ref: DatabaseReference
    private var mAuth: FirebaseAuth? = null
    lateinit var txtsignup: TextView
    lateinit var btnsignin: Button
    lateinit var txtskip: TextView
    lateinit var edtemail: EditText
    lateinit var edtpass: EditText
    lateinit var txtforgetpass:TextView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)

        txtsignup = findViewById(R.id.txtsignup)
        txtskip = findViewById(R.id.txtskip)
        btnsignin =findViewById<Button>(R.id.btnsignin)
        edtemail =findViewById<EditText>(R.id.edtemail)
        edtpass =findViewById<EditText>(R.id.edtpass)
        txtforgetpass=findViewById(R.id.txtforgetpass)




        mAuth = FirebaseAuth.getInstance()
        initView()

        val txtsignup = findViewById(R.id.txtsignup) as TextView
        txtsignup.setOnClickListener {
            startActivity(
                Intent(
                    this@SigninActivity,
                    SignupActivity::class.java
                )
            )
    }
        val txtskip = findViewById(R.id.txtskip) as TextView
        txtskip.setOnClickListener {
            startActivity(Intent(this@SigninActivity, NavigationActivity::class.java))

        }

        txtforgetpass.setOnClickListener {
            startActivity(Intent(this@SigninActivity, ForgotpassActivity::class.java))

        }

    }

    private fun initView() {
        btnsignin.setOnClickListener {

            if (edtemail.text.toString().isEmpty()) {
                edtemail.error = "can't blank"
            } else if (edtpass.text.toString().isEmpty()) {
                edtpass.error = "can't blank"

                mAuth?.signInWithEmailAndPassword(
                    edtemail.text.toString().trim(),
                    edtpass.text.toString().trim()
                )
                    ?.addOnCompleteListener(this@SigninActivity, object :
                        OnCompleteListener<AuthResult> {
                        override fun onComplete(@NonNull task: Task<AuthResult>) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d("TAG", "signInWithEmail:success")


                                val intent =
                                    Intent(this@SigninActivity, NavigationActivity::class.java)
                                prif[IS_LOGIN] = true

                                startActivity(intent)
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w("TAG", "signInWithEmail:failure", task.getException())
                                Toast.makeText(
                                    this@SigninActivity,
                                    "Authentication failed.",
                                    Toast.LENGTH_SHORT
                                ).show()


                            }

                        }
                    })


            }

        }
    }
    }




