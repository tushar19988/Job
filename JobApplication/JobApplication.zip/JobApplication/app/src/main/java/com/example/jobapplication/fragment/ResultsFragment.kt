package com.example.jobapplication.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.jobapplication.*
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class ResultsFragment : Fragment() {

    var ref: DatabaseReference?=null
    lateinit var userRecyclerView: RecyclerView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_results, container, false)

        userRecyclerView=view.findViewById(R.id.userliste)


        ref = FirebaseDatabase.getInstance().getReference("Employee")

        initView(view)
        return view
    }

    private fun initView(view: View?) {
        userRecyclerView.layoutManager = LinearLayoutManager(context)
        val firebaseAdapter = object : FirebaseRecyclerAdapter<RetriveDatae, EViewHolder>(


            RetriveDatae::class.java,
            R.layout.item_emplyoee_adapter,
            EViewHolder::class.java,
            ref
        ) {
            override fun populateViewHolder(p0: EViewHolder?, p1: RetriveDatae?, p2: Int) {
                p0?.itemView?.findViewById<TextView>(R.id.txtemp)?.setText(p1?.url)
                p0?.itemView?.findViewById<TextView>(R.id.txtexam)?.setText(p1?.exam)
                p0?.itemView?.findViewById<TextView>(R.id.txtuni)?.setText(p1?.university)
                p0?.itemView?.findViewById<TextView>(R.id.txtlocation)?.setText(p1?.location)


                p0?.itemView?.findViewById<Button>(R.id.btnview)?.setOnClickListener {

                    val rajuni  = "Rajasthan University of Health Sciences Issued the Result of B.Sc. NURSING PART-II (MAIN) EXAM. NOV.-2018 Re-Evaluation"
                    val kashmir = "University of Kashmir Announced the Result of 5th Semester Backlog Examination (Batch 2015) held in Feb-March, 2019"
                    val calicut = "University of Calicut Announced the Result of 1st And 2nd Sem M.A. Journalism And Mass Communication (CCSS) Examination"
                    val rajdiplo = "University of Rajasthan Announced the Result of PG DIPLOMA COURSE IN BANKING & FINANCE EXAM.-2019 And PG DIPLOMA IN CO-OPERATION EXAM.-2019"
                    val rajyoga = "University of Rajasthan Announced The Result of P G Diploma in Yoga Education EXAM.-2019"
                    val rajmtech = "University of Rajasthan Issed The Result of M.Tech. I SEMESTER DEC-2018 and M.Tech. III SEMESTER DEC-2018"
                    val kerela = "Govt Of Kerala Issued The Result of Higher Secondary Examination(+1 Result) 2019"
                    val bhuneshwer = "AIIMS Bhubaneswar Recruitment for Senior Medical Officer (Ayurveda),Medical OfficerAYUSH(Ayurveda and Homeopathy) - 2019"
                    val kuru = "Kurukshetra University Announced The Result of Bachelor of Science(B.Sc.) Ist Sem. (Dec-2018)"
                    val krukshetra = "Kurukshetra University Announced The Result of L.L.M. IInd Year (Dec-2018)"


                    if (rajuni.equals(p1?.url)) {
                        val intent = Intent(context, RajuniActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)

                    } else if (kashmir.equals(p1?.url)) {

                        val intent = Intent(context, KashmirActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (calicut.equals(p1?.url)) {


                        val intent = Intent(context, CalicutActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (rajdiplo.equals(p1?.url)) {

                        val intent = Intent(context, RajasthandiploActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (rajyoga.equals(p1?.url)) {

                        val intent = Intent(context, RajyogActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (rajmtech.equals(p1?.url)) {

                        val intent = Intent(context, RajasthanmtechActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }

                    else if (kerela.equals(p1?.url)) {

                        val intent = Intent(context, KerelaActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (bhuneshwer.equals(p1?.url)) {

                        val intent = Intent(context, BhuneshwerActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (kuru.equals(p1?.url)) {

                        val intent = Intent(context, KuruActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                    else if (krukshetra.equals(p1?.url)) {

                        val intent = Intent(context, KrukshetraActivity::class.java)
                        intent.putExtra("URL",p1?.url)
                        intent.putExtra("EXAM",p1?.exam)
                        intent.putExtra("UNIVERSITY",p1?.university)
                        intent.putExtra("LOCATION",p1?.location)
                        startActivity(intent)
                    }
                }

            }
        }
        userRecyclerView.adapter=firebaseAdapter
    }
    }


